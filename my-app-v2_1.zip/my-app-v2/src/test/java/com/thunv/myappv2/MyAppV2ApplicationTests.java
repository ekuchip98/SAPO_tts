package com.thunv.myappv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyAppV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
