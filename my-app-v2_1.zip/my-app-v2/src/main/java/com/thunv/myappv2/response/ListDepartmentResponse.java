package com.thunv.myappv2.response;

import lombok.Data;

import java.util.List;

@Data
public class ListDepartmentResponse {
    private int totalPage;

    private List<DepartmentResponse> dataList;
}
