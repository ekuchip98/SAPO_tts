package com.thunv.myappv2.service.impl;

import com.thunv.myappv2.entity.Department;
import com.thunv.myappv2.entity.Employee;
import com.thunv.myappv2.repository.DepartmentRepository;
import com.thunv.myappv2.repository.EmployeeRepository;
import com.thunv.myappv2.request.EmployeeRequest;
import com.thunv.myappv2.request.SearchDepartmentRequest;
import com.thunv.myappv2.request.SearchEmployeeRequest;
import com.thunv.myappv2.response.DepartmentResponse;
import com.thunv.myappv2.response.EmployeeResponse;
import com.thunv.myappv2.response.ListEmployeeResponse;
import com.thunv.myappv2.service.IEmployeeService;
import com.thunv.myappv2.util.ListMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class EmployeeServiceImpl implements IEmployeeService{

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ListMapper listMapper;

    @Override
    public List<EmployeeResponse> findAll() {
        return listMapper.mapList(employeeRepository.findAllByDelActiveTrue(), EmployeeResponse.class);
    }

    @Override
    public ListEmployeeResponse search(SearchEmployeeRequest request) {
        ListEmployeeResponse response = new ListEmployeeResponse();
        Pageable pageable = PageRequest.of(request.getPageNumber() - 1, request.getMaxPageItem());
        List<Employee> statePage = employeeRepository.search(request.getName(), pageable).getContent();
        int total = employeeRepository.countEmployee(request.getName());
        response.setTotalPage(total);
        response.setDataList(listMapper.mapList(statePage, EmployeeResponse.class));
        return response;
    }

    @Override
    public EmployeeResponse findById(Long id) {
        return modelMapper.map(employeeRepository.getById(id), EmployeeResponse.class);
    }

    @Override
    @Transactional
    public void save(EmployeeRequest request) {
        Employee employee = modelMapper.map(request, Employee.class);
        this.removeTemple(request, employee);
    }

    @Override
    @Transactional
    public void update(EmployeeRequest request) {
        Employee employeeOld = employeeRepository.getById(request.getId());
        modelMapper.map(request, employeeOld);
        this.removeTemple(request, employeeOld);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Employee employee = employeeRepository.getById(id);
        employee.setDelActive(false);
        employeeRepository.save(employee);
    }

    private void removeTemple(EmployeeRequest request, Employee employee) {
        if (!CollectionUtils.isEmpty(employee.getDepartmentList())){
            employee.getDepartmentList().forEach(department -> department.getEmployeeList().remove(employee));
        }
        List<Department> departmentList = departmentRepository.findAllById(request.getIdDepartmentList());
        employee.setDepartmentList(departmentList);
        departmentList.forEach(x->x.getEmployeeList().add(employee));
        employeeRepository.save(employee);
    }
}
