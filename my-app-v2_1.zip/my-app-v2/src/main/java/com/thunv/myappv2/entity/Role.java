package com.thunv.myappv2.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
@Entity
@Table(name = "role")
public class Role extends BaseEntity{

    @NotBlank
    private String code;

    @NotBlank
    private String name;

    @ManyToMany(mappedBy = "roleList",fetch = FetchType.EAGER)
    @JsonIgnore
    private List<User> userList;
}
