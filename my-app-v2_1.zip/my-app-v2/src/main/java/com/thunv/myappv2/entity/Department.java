package com.thunv.myappv2.entity;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "department")
public class Department extends BaseEntity{

    @NotNull
    private String code;

    private String name;

    @ManyToMany(mappedBy = "departmentList")
    private List<Employee> employeeList;

//    public Department(Department entity) {
//        if(entity!=null){
//            this.code = entity.code;
//            this.name = entity.name;
//            if()
//        }
//    }
}
