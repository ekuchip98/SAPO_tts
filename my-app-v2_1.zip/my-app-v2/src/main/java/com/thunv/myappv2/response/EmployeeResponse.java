package com.thunv.myappv2.response;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class EmployeeResponse {

    private String code;

    private String firstName;

    private String lastName;

    private String gender;

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private Date birthDay;

    private String email;

    private String position;
}
