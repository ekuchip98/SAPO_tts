package com.thunv.myappv2.response;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class IdResponse {

    @NotNull
    private Long id;
}
