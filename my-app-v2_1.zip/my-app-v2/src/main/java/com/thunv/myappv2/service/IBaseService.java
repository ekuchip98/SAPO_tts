package com.thunv.myappv2.service;

public interface IBaseService<T> {

    void save(T request);

    void update(T request);

    void delete(Long id);

}
