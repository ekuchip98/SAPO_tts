package com.thunv.myappv2.controller;

import com.thunv.myappv2.request.DepartmentRequest;
import com.thunv.myappv2.request.EmployeeRequest;
import com.thunv.myappv2.request.SearchDepartmentRequest;
import com.thunv.myappv2.request.SearchEmployeeRequest;
import com.thunv.myappv2.response.DepartmentResponse;
import com.thunv.myappv2.response.EmployeeResponse;
import com.thunv.myappv2.response.ListDepartmentResponse;
import com.thunv.myappv2.response.ListEmployeeResponse;
import com.thunv.myappv2.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("employee")
public class EmployeeController {

    @Autowired
    private IEmployeeService IEmployeeService;

    @GetMapping("/search")
    ResponseEntity<ListEmployeeResponse> searchEmployee(@Valid SearchEmployeeRequest request){
        return ResponseEntity.ok(IEmployeeService.search(request));
    }

    @GetMapping("/all")
    ResponseEntity<List<EmployeeResponse>> findAll(){
        return ResponseEntity.ok(IEmployeeService.findAll());
    }

    @GetMapping("/{id}")
    ResponseEntity<EmployeeResponse> findById(@PathVariable Long id){
        return ResponseEntity.ok(IEmployeeService.findById(id));
    }

    @PutMapping
    ResponseEntity updateEmployee(@Valid @RequestBody EmployeeRequest request){
        IEmployeeService.update(request);
        return ResponseEntity.ok("Cap nhat thanh cong");
    }

    @DeleteMapping("{id}")
    ResponseEntity deleteEmployee(@PathVariable Long id){
        IEmployeeService.delete(id);
        return ResponseEntity.ok("Xoa thanh cong");
    }

    @PostMapping
    ResponseEntity saveEmployee(@Valid @RequestBody EmployeeRequest request){
        IEmployeeService.save(request);
        return ResponseEntity.ok("Them thanh cong");
    }
}
