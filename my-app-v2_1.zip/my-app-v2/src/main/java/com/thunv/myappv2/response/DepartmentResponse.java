package com.thunv.myappv2.response;

import lombok.Data;

@Data
public class DepartmentResponse extends IdResponse{

    private String code;

    private String name;
}
