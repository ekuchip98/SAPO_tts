package com.thunv.myappv2.repository;

import com.thunv.myappv2.entity.Department;
import com.thunv.myappv2.request.SearchDepartmentRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    List<Department> findAllByDelActiveTrueOrderByCodeDesc();

    @Query(value = "SELECT e FROM Department e WHERE e.name LIKE %:name% AND e.delActive = true order by e.id DESC ")
    Page<Department> search(String name, Pageable pageable);

    @Query("SELECT count(d.id) FROM Department d where d.name like %:name% AND d.delActive = true")
    int countDepartment(String name);
}
