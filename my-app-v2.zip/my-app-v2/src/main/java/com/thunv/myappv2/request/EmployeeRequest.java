package com.thunv.myappv2.request;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class EmployeeRequest extends IdRequest{

    private String code;

    private String firstName;

    private String lastName;

    private String gender;

    private Date birthDay;

    private String email;

    private String position;

    private List<Long> idDepartmentList;
}
