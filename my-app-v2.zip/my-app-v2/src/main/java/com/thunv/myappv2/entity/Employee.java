package com.thunv.myappv2.entity;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Entity
@Table(name = "employee")
public class Employee extends BaseEntity{

    @NotBlank
    @Column(nullable = false)
    private String code;

    @NotBlank
    @Column(nullable = false)
    private String firstName;

    private String lastName;

    @NotNull
    @Column(nullable = false)
    private String gender;

    @NotNull
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private Date birthDay;

    @Email
    @NotBlank
    @Column(nullable = false)
    private String email;

    private String position;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "employee_department",
            joinColumns = @JoinColumn(name = "employee_id"),
            inverseJoinColumns = @JoinColumn(name = "department_id") )
    private List<Department> departmentList;
}
