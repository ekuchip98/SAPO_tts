package com.thunv.myappv2.service.impl;

import com.thunv.myappv2.entity.Department;
import com.thunv.myappv2.repository.DepartmentRepository;
import com.thunv.myappv2.request.DepartmentRequest;
import com.thunv.myappv2.request.SearchDepartmentRequest;
import com.thunv.myappv2.response.DepartmentResponse;
import com.thunv.myappv2.response.ListDepartmentResponse;
import com.thunv.myappv2.service.IDepartmentService;
import com.thunv.myappv2.util.ListMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class DepartmentServiceImpl implements IDepartmentService{

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ListMapper listMapper;

    @Override
    public ListDepartmentResponse search(SearchDepartmentRequest request) {
        ListDepartmentResponse response = new ListDepartmentResponse();
        Pageable pageable = PageRequest.of(request.getPageNumber() - 1, request.getMaxPageItem());
        List<Department> statePage = departmentRepository.search(request.getName(), pageable).getContent();
        int total = departmentRepository.countDepartment(request.getName());
        response.setTotalPage(total);
        response.setDataList(listMapper.mapList(statePage, DepartmentResponse.class));
        return response;
    }

    @Override
    public List<DepartmentResponse> findAll() {
        return listMapper.mapList(departmentRepository.findAllByDelActiveTrueOrderByCodeDesc(), DepartmentResponse.class);
    }

    @Override
    public DepartmentResponse findById(Long id) {
        return modelMapper.map(departmentRepository.getById(id), DepartmentResponse.class);
    }

    @Override
    @Transactional
    public void save(DepartmentRequest request) {
        Department department = modelMapper.map(request, Department.class);
        departmentRepository.save(department);
    }

    @Override
    @Transactional
    public void update(DepartmentRequest request) {
        Department departmentOld = departmentRepository.getById(request.getId());
        modelMapper.map(request, departmentOld);
        departmentRepository.save(departmentOld);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Department department = departmentRepository.getById(id);
        department.setDelActive(false);
        departmentRepository.save(department);
    }
}
