package com.thunv.myappv2.repository;

import com.thunv.myappv2.entity.Department;
import com.thunv.myappv2.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findAllByDelActiveTrue();

    @Query(value = "SELECT e FROM Employee e WHERE e.firstName LIKE %:name% AND e.delActive = true order by e.id DESC ")
    Page<Employee> search(String name, Pageable pageable);

    @Query("SELECT count(e.id) FROM Employee e where e.firstName like %:name% AND e.delActive = true")
    int countEmployee(String name);
}
