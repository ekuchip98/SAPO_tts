package com.thunv.myappv2.constant;

public interface ErrorsConstant {
    String NOT_FOUND_DATABASE_DELETE = "Không tồn tại dữ liệu trong hệ thống";
}
