package com.thunv.myappv2.request;

import lombok.Data;

@Data
public class SearchEmployeeRequest extends PageRequest{

    private String name;
}
