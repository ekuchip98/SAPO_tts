package com.thunv.myappv2.response;

import lombok.Data;

import java.util.List;

@Data
public class ListEmployeeResponse extends IdResponse{

    private int totalPage;

    private List<EmployeeResponse> dataList;

}
