package com.thunv.myappv2.request;

import lombok.Data;

@Data
public class DepartmentRequest extends IdRequest{

    private String code;

    private String name;
}
