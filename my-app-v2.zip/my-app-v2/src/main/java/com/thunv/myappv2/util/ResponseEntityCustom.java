package com.thunv.myappv2.util;

public class ResponseEntityCustom {

}
