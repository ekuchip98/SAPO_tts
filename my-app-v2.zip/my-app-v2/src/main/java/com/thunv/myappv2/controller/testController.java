package com.thunv.myappv2.controller;

import com.thunv.myappv2.entity.User;
import com.thunv.myappv2.repository.RoleRepository;
import com.thunv.myappv2.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class testController {

    @GetMapping("/random")
    public String randomStuff(){
        return "JWT Hợp lệ mới có thể thấy được message này GET";
    }

    @PostMapping("/random")
    public String randomStuff1(){
        return "JWT Hợp lệ mới có thể thấy được message này POST";
    }
}
