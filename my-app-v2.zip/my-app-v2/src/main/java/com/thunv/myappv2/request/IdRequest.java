package com.thunv.myappv2.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class IdRequest {

    @NotNull
    private Long id;
}
