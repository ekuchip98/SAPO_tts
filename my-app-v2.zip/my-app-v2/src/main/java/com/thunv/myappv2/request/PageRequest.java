package com.thunv.myappv2.request;

import lombok.Data;

@Data
public class PageRequest {

    private int pageNumber;

    private int maxPageItem;
}
