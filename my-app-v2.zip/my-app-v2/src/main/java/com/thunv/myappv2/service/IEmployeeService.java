package com.thunv.myappv2.service;

import com.thunv.myappv2.request.EmployeeRequest;
import com.thunv.myappv2.request.SearchEmployeeRequest;
import com.thunv.myappv2.response.EmployeeResponse;
import com.thunv.myappv2.response.ListEmployeeResponse;

import java.util.List;

public interface IEmployeeService extends IBaseService<EmployeeRequest>{

    List<EmployeeResponse> findAll();

    ListEmployeeResponse search(SearchEmployeeRequest request);

    EmployeeResponse findById(Long id);

}
