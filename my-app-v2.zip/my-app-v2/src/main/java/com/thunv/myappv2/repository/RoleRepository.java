package com.thunv.myappv2.repository;

import com.thunv.myappv2.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
