package com.thunv.myappv2.service;

import com.thunv.myappv2.request.DepartmentRequest;
import com.thunv.myappv2.request.SearchDepartmentRequest;
import com.thunv.myappv2.response.DepartmentResponse;
import com.thunv.myappv2.response.ListDepartmentResponse;

import java.util.List;

public interface IDepartmentService extends IBaseService<DepartmentRequest>  {

    ListDepartmentResponse search(SearchDepartmentRequest request);

    List<DepartmentResponse> findAll();

    DepartmentResponse findById(Long id);
}
