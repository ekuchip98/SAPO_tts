package com.thunv.myappv2.controller;

import com.thunv.myappv2.request.DepartmentRequest;
import com.thunv.myappv2.request.SearchDepartmentRequest;
import com.thunv.myappv2.response.DepartmentResponse;
import com.thunv.myappv2.response.ListDepartmentResponse;
import com.thunv.myappv2.service.IDepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("department")
public class DepartmentController {

    @Autowired
    private IDepartmentService IDepartmentService;

    @GetMapping("/search")
    ResponseEntity<ListDepartmentResponse> searchDepartment(@Valid SearchDepartmentRequest request){
        return ResponseEntity.ok(IDepartmentService.search(request));
    }

    @GetMapping("/all")
    ResponseEntity<List<DepartmentResponse>> findAll(){
        return ResponseEntity.ok(IDepartmentService.findAll());
    }

    @GetMapping("/{id}")
    ResponseEntity<DepartmentResponse> findById(@PathVariable Long id){
        return ResponseEntity.ok(IDepartmentService.findById(id));
    }

    @PostMapping
    ResponseEntity saveDepartment(@Valid @RequestBody DepartmentRequest request){
        IDepartmentService.save(request);
        return ResponseEntity.ok("Them thanh cong");
    }

    @PutMapping
    ResponseEntity updateDepartment(@Valid @RequestBody DepartmentRequest request){
        IDepartmentService.update(request);
        return ResponseEntity.ok("Cap nhat thanh cong");
    }

    @DeleteMapping("{id}")
    ResponseEntity deleteDepartment(@PathVariable Long id){
        IDepartmentService.delete(id);
        return ResponseEntity.ok("Xoa thanh cong");
    }
}
